package game_engine;

//Sound related data, such as what file to play and at what volume
//Possibly playback speed etc

public class Sound extends Component {
	double volume = 1;
}
