package game_engine;

public class Collider extends Component {

}
