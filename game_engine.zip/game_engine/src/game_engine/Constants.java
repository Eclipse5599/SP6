package game_engine;

//Holds constants for the game

public final class Constants {
	public static enum ComponentType{graphic, physics, sound, controller};
}
